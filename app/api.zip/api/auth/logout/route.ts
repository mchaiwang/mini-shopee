import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST() {
  const res = NextResponse.json({ success: true });

  res.cookies.set("auth", "", {
    path: "/",
    expires: new Date(0),
  });

  res.cookies.set("admin", "", {
    path: "/",
    expires: new Date(0),
  });

  return res;
}
